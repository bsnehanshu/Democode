# Democode
Will be used for live demos

Hi Humans

Snehanshu here, I like data center architectural componants which can be virtualised.
I've had burger in the morning although it is 2nd thrusday in Margshish calender.

